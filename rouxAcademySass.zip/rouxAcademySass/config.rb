require 'susy'
css_dir ='/css'
sass_dir= '/components/sass'
javascripts_dir = '/js'
output_style = :compressed
